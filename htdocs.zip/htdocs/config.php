<?php

$db_user = "root";
$db_pwd = "";
$db_name = "users";

$db = new PDO('mysql:host=localhost;dbname =' . $db_name . ';charset=utf8', $db_user, $db_pwd);
$db->SetAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


?>