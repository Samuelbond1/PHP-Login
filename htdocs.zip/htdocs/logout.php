<?php
session_start();
//session destroy
session_destroy();
header("Location: http://localhost/index.php");
?>